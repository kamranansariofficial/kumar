import React from "react";
import Typography from "@mui/material/Typography";

export default function Home() {
  return (
    <div>
      <Typography variant="h5" color="text.primary">
        Hello from Home
      </Typography>
    </div>
  );
}
